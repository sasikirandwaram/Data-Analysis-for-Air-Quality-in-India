# Data Analysis for Air Quality in India
It is an analytics on data of air quality in India.
